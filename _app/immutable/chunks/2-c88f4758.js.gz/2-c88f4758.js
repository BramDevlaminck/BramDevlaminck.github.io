import{default as t}from"../components/pages/_page.svelte-6a601a15.js";export{t as component};
