import{default as t}from"../components/error.svelte-9e223470.js";export{t as component};
