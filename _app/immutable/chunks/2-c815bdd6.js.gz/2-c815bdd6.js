import{default as t}from"../components/pages/_page.svelte-64f2b7aa.js";export{t as component};
