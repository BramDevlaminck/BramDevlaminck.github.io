import{default as t}from"../components/pages/_page.svelte-47525fff.js";export{t as component};
