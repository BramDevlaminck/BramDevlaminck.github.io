import{default as t}from"../components/pages/_page.svelte-3ca436ef.js";export{t as component};
